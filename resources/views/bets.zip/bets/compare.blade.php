@extends('layouts.app')
@section('content')
<style type="text/css">
	@media (min-width: 1400px){
		.m-container.m-container--responsive.m-container--xxl {
		    width: 100vw!important;
		}
	}
</style>
<div class="m-portlet m-portlet--head-solid-bg m-portlet--rounded">
    <div class="m-portlet__body">
    	<div class="row">
    		<div class="col-md-6">
    			<table class="table table-striped- table-bordered table-hover table-checkable">
	                <thead>
	                    <tr>
	                    	<th>Tipo</th>
	                        <th>Player</th>
	                        <th>Partidos</th>
	                        <th>Op</th>
	                        <th>Failed</th>
	                        <th>Succ</th>
	                        <th>0.5%</th>
	                        <th>1.5%</th>
	                        <th>2.5%</th>
	                        <th>3.5%</th>
	                        <th>4.5%</th>
	                        <th>5.5%</th>
	                    </tr>
	                </thead>
	                <tbody>
	                    @if(!empty($data_p1))
	                        @foreach($data_p1 as $key => $dx)
	                        	@foreach($dx as $p1d1)
	                        	<tr >
	                        		@php
	                        			$p1d1 = (array)$p1d1;
	                                    $fail = 0;
	                                    $op_1 = 0;
	                                    $op_succ = 0;
	                                    $opo_por = 0;
	                                    
	                                    if($p1d1['partidos_jugados'] > 0){
	                                        $por = @$p1d1['aciertos']*100/@$p1d1['partidos_jugados'];
	                                        $por_35 = round(@$p1d1['tree']*100/@$p1d1['partidos_jugados']);
	                                        $por_45 = round(@$p1d1['four']*100/@$p1d1['partidos_jugados']);
	                                        $por_55 = round(@$p1d1['five']*100/@$p1d1['partidos_jugados']);
	                                        $por_15 = round(@$p1d1['one']*100/@$p1d1['partidos_jugados']);
	                                        $por_05 = round(@$p1d1['zero']*100/@$p1d1['partidos_jugados']);
                                    		$fail = $p1d1['partidos_jugados'] - $p1d1['zero'];
	                                        $op_1 = $fail+($p1d1['zero']-$p1d1['one']);
	                                        $op_succ = ($op_1-$fail);
                                    		$opo_por = $op_1 > 0 ? round(($op_1-$fail) * 100 / $op_1) : "-" ;

	                                    }
	                                @endphp

	                                <td>{{@$key}}</td>
	                                <td>{{ @$players[$player1] }}</td>
	                                <td>{{ $p1d1['partidos_jugados'] }}</td>
	                                <td>{{round($op_1)}}</td>
	                                <td>{{round($fail)}}</td>
	                                <td>{{round($op_succ)}}</td>
	                                <td>{{round($por_05)}}</td>
	                                <td>{{round($por_15)}}</td>
	                                <td>{{round($por)}}</td>
	                                <td>{{round($por_35)}}</td>
	                                <td>{{round($por_45)}}</td>
	                                <td>{{round($por_55)}}</td>
	                            </tr>
	                        	@endforeach
	                        @endforeach
	                    @endif
	                </tbody>
	            </table> 
    		</div>
    		<div class="col-md-6">
    			<table class="table table-striped- table-bordered table-hover table-checkable">
	                <thead>
	                    <tr>
	                        <th>Player</th>
	                        <th>Partidos</th>
	                        <th>0.5%</th>
	                        <th>1.5%</th>
	                        <th>2.5%</th>
	                        <th>3.5%</th>
	                        <th>4.5%</th>
	                        <th>5.5%</th>
	                    </tr>
	                </thead>
	                <tbody>
	                    @if(!empty($data_p2))
	                        @foreach($data_p2 as $key => $dx)
	                        	@foreach($dx as $p1d2)
	                        	<tr >
	                        		@php
	                        			$p1d2 = (array)$p1d2;
	                                    $por = 0;
	                                    if($p1d2['partidos_jugados'] > 0){
	                                        $por = @$p1d2['aciertos']*100/@$p1d2['partidos_jugados'];
	                                        $por_35 = round(@$p1d2['tree']*100/@$p1d2['partidos_jugados']);
	                                        $por_15 = round(@$p1d2['one']*100/@$p1d2['partidos_jugados']);
	                                        $por_05 = round(@$p1d2['zero']*100/@$p1d2['partidos_jugados']);
	                                        $por_45 = round(@$p1d2['four']*100/@$p1d2['partidos_jugados']);
	                                        $por_55 = round(@$p1d2['five']*100/@$p1d2['partidos_jugados']);
	                                    }
	                                @endphp

	                                <td>{{ @$players[$player2] }}</td>
	                                <td>{{ $p1d2['partidos_jugados'] }}</td>
	                                <td>{{round($por_05)}}</td>
	                                <td>{{round($por_15)}}</td>
	                                <td>{{round($por)}}</td>
	                                <td>{{round($por_35)}}</td>
	                                <td>{{round($por_45)}}</td>
	                                <td>{{round($por_55)}}</td>
	                            </tr>
	                        	@endforeach
	                        @endforeach
	                    @endif
	                </tbody>
	            </table> 
    		</div>
    		<div class="col-md-6">
    			<table class="table table-striped- table-bordered table-hover table-checkable">
	                <thead>
	                    <tr>
	                        <th>Player</th>
	                        <th>Enemigo</th>
	                        <th>Partidos</th>
	                        <th>6.5%</th>
	                        <th>5.5%</th>
	                        <th>4.5%</th>
	                        <th>3.5%</th>
	                        <th>2.5%</th>
	                        <th>1.5%</th>
	                        <th>0.5%</th>
	                        <th>0 %</th>
	                    </tr>
	                </thead>
	                <tbody>
	                    @if(!empty($global_partidos))
	                        @foreach($global_partidos as $bet2ene)
	                        		@php
	                        			$bet2ene = (array)$bet2ene;
	                                    $por = 0;

	                                    if($bet2ene['partidos_jugados'] > 0){
	                                        $por = @$bet2ene['aciertos']*100/@$bet2ene['partidos_jugados'];
	                                        $por_65 = round(@$bet2ene['six']*100/@$bet2ene['partidos_jugados']);
	                                        $por_55 = round(@$bet2ene['five']*100/@$bet2ene['partidos_jugados']);
	                                        $por_45 = round(@$bet2ene['four']*100/@$bet2ene['partidos_jugados']);
	                                        $por_35 = round(@$bet2ene['tree']*100/@$bet2ene['partidos_jugados']);
	                                        $por_15 = round(@$bet2ene['one']*100/@$bet2ene['partidos_jugados']);
	                                        $por_05 = round(@$bet2ene['zero']*100/@$bet2ene['partidos_jugados']);
	                                        $por_0 = round((@$bet2ene['partidos_jugados']-@$bet2ene['zero']));
	                                    }
	                                @endphp
		                        	<tr >
		                                <td>{{ @$players[$player1] }}</td>
		                                <td>{{ @$players[$player2] }}</td>
		                                <td>{{ $bet2ene['partidos_jugados'] }}</td>
	                                    <td>{{round($por_65)}} </td>
	                                    <td>{{round($por_55)}} </td>
	                                    <td>{{round($por_45)}} </td>
	                                    <td>{{round($por_35)}} </td>
	                                    <td>{{round($por)}} ({{ $bet2ene['aciertos'] - $bet2ene['tree']}})</td>
	                                    <td>{{round($por_15)}} ({{ $bet2ene['one'] - $bet2ene['aciertos']}})</td>
		                                <td>{{round($por_05)}} ({{ $bet2ene['zero'] - $bet2ene['one']}})</td>
		                                <td>{{round($por_0)}}</td>
		                            </tr>
	                            
	                        @endforeach
	                    @endif
	                    @if(!empty($global_vs_actual))
	                        @foreach($global_vs_actual as $bet2enevs)
	                        		@php
	                        			$bet2enevs = (array)$bet2enevs;
	                                    $por = 0;

	                                    if($bet2enevs['partidos_jugados'] > 0){
	                                        $por = @$bet2enevs['aciertos']*100/@$bet2enevs['partidos_jugados'];
	                                        $por_65 = round(@$bet2enevs['six']*100/@$bet2enevs['partidos_jugados']);
	                                        $por_55 = round(@$bet2enevs['five']*100/@$bet2enevs['partidos_jugados']);
	                                        $por_45 = round(@$bet2enevs['four']*100/@$bet2enevs['partidos_jugados']);
	                                        $por_35 = round(@$bet2enevs['tree']*100/@$bet2enevs['partidos_jugados']);
	                                        $por_15 = round(@$bet2enevs['one']*100/@$bet2enevs['partidos_jugados']);
	                                        $por_05 = round(@$bet2enevs['zero']*100/@$bet2enevs['partidos_jugados']);
	                                        $por_0 = round((@$bet2enevs['partidos_jugados']-@$bet2enevs['zero']));
	                                    }
	                                @endphp
		                        	<tr >
		                                <td>{{ @$players[$player1] }}</td>
		                                <td>{{ @$players[$player2] }}</td>
		                                <td>{{ $bet2enevs['partidos_jugados'] }}</td>
		                                
	                                    <td>{{round($por_65)}} </td>
	                                    <td>{{round($por_55)}} </td>
	                                    <td>{{round($por_45)}} </td>
	                                    <td>{{round($por_35)}} </td>
	                                    <td>{{round($por)}} ({{ $bet2enevs['aciertos'] - $bet2enevs['tree']}})</td>
	                                    <td>{{round($por_15)}} ({{ $bet2enevs['one'] - $bet2enevs['aciertos']}})</td>
		                                <td>{{round($por_05)}} ({{ $bet2enevs['zero'] - $bet2enevs['one']}})</td>
		                                <td>{{round($por_0)}}</td>
		                            </tr>
	                        @endforeach
	                    @endif
	                    @if(!empty($global_vs_tree))
	                        @foreach($global_vs_tree as $bet2enevst)
	                        		@php
	                        			$bet2enevst = (array)$bet2enevst;
	                                    $por = 0;

	                                    if($bet2enevst['partidos_jugados'] > 0){
	                                        $por = @$bet2enevst['aciertos']*100/@$bet2enevst['partidos_jugados'];
	                                        $por_65 = round(@$bet2enevst['six']*100/@$bet2enevst['partidos_jugados']);
	                                        $por_55 = round(@$bet2enevst['five']*100/@$bet2enevst['partidos_jugados']);
	                                        $por_45 = round(@$bet2enevst['four']*100/@$bet2enevst['partidos_jugados']);
	                                        $por_35 = round(@$bet2enevst['tree']*100/@$bet2enevst['partidos_jugados']);
	                                        $por_15 = round(@$bet2enevst['one']*100/@$bet2enevst['partidos_jugados']);
	                                        $por_05 = round(@$bet2enevst['zero']*100/@$bet2enevst['partidos_jugados']);
	                                        $por_0 = round((@$bet2enevst['partidos_jugados']-@$bet2enevst['zero']));
	                                    }
	                                @endphp
		                        	<tr >
		                                <td>{{ @$players[$player1] }}</td>
		                                <td>{{ @$players[$player2] }}</td>
		                                <td>{{ $bet2enevst['partidos_jugados'] }}</td>
		                                
	                                    <td>{{round($por_65)}} </td>
	                                    <td>{{round($por_55)}} </td>
	                                    <td>{{round($por_45)}} </td>
	                                    <td>{{round($por_35)}} </td>
	                                    <td>{{round($por)}} ({{ $bet2enevst['aciertos'] - $bet2enevst['tree']}})</td>
	                                    <td>{{round($por_15)}} ({{ $bet2enevst['one'] - $bet2enevst['aciertos']}})</td>
		                                <td>{{round($por_05)}} ({{ $bet2enevst['zero'] - $bet2enevst['one']}})</td>
		                                <td>{{round($por_0)}}</td>
		                            </tr>
	                        @endforeach
	                    @endif
	                    @if(!empty($global_vs_week))
	                        @foreach($global_vs_week as $bet2enevs)
	                        		@php
	                        			$bet2enevs = (array)$bet2enevs;
	                                    $por = 0;

	                                    if($bet2enevs['partidos_jugados'] > 0){
	                                        $por = @$bet2enevs['aciertos']*100/@$bet2enevs['partidos_jugados'];
	                                        $por_65 = round(@$bet2enevs['six']*100/@$bet2enevs['partidos_jugados']);
	                                        $por_55 = round(@$bet2enevs['five']*100/@$bet2enevs['partidos_jugados']);
	                                        $por_45 = round(@$bet2enevs['four']*100/@$bet2enevs['partidos_jugados']);
	                                        $por_35 = round(@$bet2enevs['tree']*100/@$bet2enevs['partidos_jugados']);
	                                        $por_15 = round(@$bet2enevs['one']*100/@$bet2enevs['partidos_jugados']);
	                                        $por_05 = round(@$bet2enevs['zero']*100/@$bet2enevs['partidos_jugados']);
	                                        $por_0 = round((@$bet2enevs['partidos_jugados']-@$bet2enevs['zero']));
	                                    }
	                                @endphp
		                        	<tr >
		                                <td>{{ @$players[$player1] }}</td>
		                                <td>{{ @$players[$player2] }}</td>
		                                <td>{{ $bet2enevs['partidos_jugados'] }}</td>
		                                
	                                    <td>{{round($por_65)}} </td>
	                                    <td>{{round($por_55)}} </td>
	                                    <td>{{round($por_45)}} </td>
	                                    <td>{{round($por_35)}} </td>
	                                    <td>{{round($por)}} ({{ $bet2enevs['aciertos'] - $bet2enevs['tree']}})</td>
	                                    <td>{{round($por_15)}} ({{ $bet2enevs['one'] - $bet2enevs['aciertos']}})</td>
		                                <td>{{round($por_05)}} ({{ $bet2enevs['zero'] - $bet2enevs['one']}})</td>
		                                <td>{{round($por_0)}}</td>
		                            </tr>
	                        @endforeach
	                    @endif

	                </tbody>
            	</table> 
    		</div>
    		<div class="col-md-6">
    			<table class="table table-striped- table-bordered table-hover table-checkable">
	                <thead>
	                    <tr>
	                        <th>Player1</th>
	                        <th>Player2</th>
	                        <th>Team 1</th>
	                        <th>Team 2</th>
	                        <th>Fecha</th>
	                        <th>Hora</th>
	                        <th>F1</th>
	                        <th>F2</th>
	                        <th>FT</th>
	                    </tr>
	                </thead>
	                <tbody>
	                    @if(!empty($global_vs_det))
	                    @php
						    $previousDate = null; // Variable para almacenar la fecha anterior
						    $colorIndex = 0; // Variable para controlar el color a aplicar
						    $colors = ['lightgrey', 'lightblue', 'lightgreen']; // Arreglo con los tres colores
						@endphp
	                        @foreach($global_vs_det as $key => $pd)
	                        
	                        	@php
                        			$pd = (array)$pd;
                        			$isNewDate = $previousDate !== $pd['fecha'];
        
							        if ($isNewDate) {
							            $colorIndex = ($colorIndex + 1) % 3; // Cambia el color entre 0, 1 y 2
							        }
	                        	@endphp
	                        	<tr style="background-color: {{ $colors[$colorIndex] }};">
	                                <td>{{ @$players[$pd['jugador']] }}</td>
	                                <td>{{ @$players[$pd['jugador2']] }}</td>
	                                <td>{{ $pd['team1'] }}</td>
	                                <td>{{ $pd['team2'] }}</td>
	                                <td>{{ $pd['fecha'] }}</td>
	                                <td>{{ $pd['hora'] }}</td>
	                                <td>{{ $pd['finals1'] }}</td>
	                                <td>{{ $pd['finals2'] }}</td>
	                                <td>{{ $pd['ft'] }}</td>
	                            </tr>
	                            @php
							        // Actualizamos la fecha anterior con la fecha actual
							        $previousDate = $pd['fecha'];
							    @endphp
	                        @endforeach
	                    @endif
	                </tbody>
	            </table> 
    		</div>
    		<div class="col-md-6">
    			<table class="table table-striped- table-bordered table-hover table-checkable">
	                <thead>
	                    <tr>
	                        <th>Player1</th>
	                        <th>Player2</th>
	                        <th>Team 1</th>
	                        <th>Team 2</th>
	                        <th>Fecha</th>
	                        <th>Hora</th>
	                        <th>F1</th>
	                        <th>F2</th>
	                        <th>FT</th>
	                    </tr>
	                </thead>
	                <tbody>
	                    @if(!empty($vs_p1))
	                        @foreach($vs_p1 as $key => $p1)
	                        
	                        	@php
	                        			$p1 = (array)$p1;
	                        	@endphp
	                        	<tr >
	                                <td>{{ @$players[$p1['jugador']] }}</td>
	                                <td>{{ @$players[$p1['jugador2']] }}</td>
	                                <td>{{ $p1['team1'] }}</td>
	                                <td>{{ $p1['team2'] }}</td>
	                                <td>{{ $p1['fecha'] }}</td>
	                                <td>{{ $p1['hora'] }}</td>
	                                <td>{{ $p1['finals1'] }}</td>
	                                <td>{{ $p1['finals2'] }}</td>
	                                <td>{{ $p1['ft'] }}</td>
	                            </tr>
	                        @endforeach
	                    @endif
	                </tbody>
	            </table> 
    		</div>
    		<div class="col-md-6">
    			<table class="table table-striped- table-bordered table-hover table-checkable">
	                <thead>
	                    <tr>
	                        <th>Player1</th>
	                        <th>Player2</th>
	                        <th>Team 1</th>
	                        <th>Team 2</th>
	                        <th>Fecha</th>
	                        <th>Hora</th>
	                        <th>F1</th>
	                        <th>F2</th>
	                        <th>FT</th>
	                    </tr>
	                </thead>
	                <tbody>
	                    @if(!empty($vs_p2))
	                        @foreach($vs_p2 as $key => $p2)
	                        
	                        	@php
	                        			$p2 = (array)$p2;
	                        	@endphp
	                        	<tr >
	                                <td>{{ @$players[$p2['jugador']] }}</td>
	                                <td>{{ @$players[$p2['jugador2']] }}</td>
	                                <td>{{ $p2['team1'] }}</td>
	                                <td>{{ $p2['team2'] }}</td>
	                                <td>{{ $p2['fecha'] }}</td>
	                                <td>{{ $p2['hora'] }}</td>
	                                <td>{{ $p2['finals1'] }}</td>
	                                <td>{{ $p2['finals2'] }}</td>
	                                <td>{{ $p2['ft'] }}</td>
	                            </tr>
	                        @endforeach
	                    @endif
	                </tbody>
	            </table> 
    		</div>
    		
    		
    		<div class="col-md-12">
    			<table class="table table-striped- table-bordered table-hover table-checkable datatables_p">
	                <thead>
	                    <tr>
	                        <th>Player</th>
	                        <th>Enemigo</th>
	                        <th>Team1</th>
	                        <th>Team2</th>
	                        <th>Partidos</th>
	                        <th>Success</th>
	                        <th>Failed</th>
	                        <th>2.5%</th>
	                        <th>3.5%</th>
	                        <th>1.5%</th>
	                        <th>0.5%</th>
	                    </tr>
	                </thead>
	                <tbody>
	                    @if(!empty($global_partidos_team))
	                        @foreach($global_partidos_team as $bet2eneteam)
	                        		@php
	                        			$bet2eneteam = (array)$bet2eneteam;
	                                    $por = 0;

	                                    if($bet2eneteam['partidos_jugados'] > 0){
	                                        $por = @$bet2eneteam['aciertos']*100/@$bet2eneteam['partidos_jugados'];
	                                        $por_35 = round(@$bet2eneteam['tree']*100/@$bet2eneteam['partidos_jugados']);
	                                        $por_15 = round(@$bet2eneteam['one']*100/@$bet2eneteam['partidos_jugados']);
	                                        $por_05 = round(@$bet2eneteam['zero']*100/@$bet2eneteam['partidos_jugados']);
	                                    }
	                                @endphp
		                        	<tr >
		                                <td>{{ @$players[$player1] }}</td>
		                                <td>{{ @$players[$player2] }}</td>
		                                <td>{{ $bet2eneteam['team1'] }}</td>
		                                <td>{{ $bet2eneteam['team2'] }}</td>
		                                <td>{{ $bet2eneteam['partidos_jugados'] }}</td>
		                                <td>{{ $bet2eneteam['aciertos'] }}</td>
		                                <td>{{ $bet2eneteam['fallos'] }}</td>
		                                
	                                    <td>{{round($por)}}</td>
	                                    <td>{{round($por_35)}}</td>
	                                    <td>{{round($por_15)}}</td>
		                                <td>{{round($por_05)}}</td>
		                            </tr>
	                            
	                        @endforeach
	                    @endif
	                </tbody>
            	</table> 
    		</div>
    	</div>
   	</div>
</div>
<script type="text/javascript">
        $(document).ready(function() {
        	$(".datatables_p").DataTable()
        })
</script>
@endsection
