@extends('layouts.app',['title' => "Usuarios",'subtitle' => 'Listado'])
@section('content')
<script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
<style type="text/css">
	@media (min-width: 1400px){
		.m-container.m-container--responsive.m-container--xxl {
		    width: 100vw!important;
		}
	}
</style>
<div class="m-portlet m-portlet--head-solid-bg m-portlet--rounded">
    <div class="m-portlet__body">
        <div class="m-form__section m-form__section--first">
            {!! Form::open(array('class' => 'm-form','route' => 'bets.show','method'=>'GET','id' => 'FormFilter')) !!}

            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <strong>Selector Jugadores</strong>
                        <input type="text" class="form-control" id="import_players_actual" name="import_players_actual">
                    </div>
                </div>
                <div class="col-md-6">
                    <button type="button" id="load_players" style="margin-top: 15px" class="btn btn-outline-info">Cargar Players</button>
                    <button type="button" id="compare_players" style="margin-top: 15px" class="btn btn-outline-warning">Comparar</button>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <strong>Jugador</strong>
                        {!! Form::select('player[]', $players , null , array('placeholder' => 'Filtrar Jugador','multiple' => 'multiple','class' => 'form-control  required select2', 'id' => 'players')) !!}
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <strong>Fecha</strong>
                        <input class="form-control" type="text" name="daterange" value="01/01/2018 - 01/15/2018" />
                    </div>
                </div>
                <div class="col-md-3">
                    <button type="submit" style="margin-top: 15px" class="btn btn-outline-success">Cargar Datos</button>
                </div>
            </div>
        {!! Form::close() !!}
        </div>      
        <div class="row " id="indicadores" style="display: none;">
            <div class="col-md-1"></div>
    <div class="col-md-2">
        <div class="m-portlet m-portlet--head-solid-bg m-portlet--rounded" style="border-style: solid;">
            <div style="border-radius: 30px;">
               <br>
                <h4 style="text-align: center;">MVP</h4>
                <h4 style="text-align: center;" class="name_text">({{@$mvp}})</h4>
                <br>
                 <h3 style="text-align: center;" id="percentage">{{@$mvp_per}} %</h3>
                <br>
            </div>
        </div>
    </div>
    <div class="col-md-2">
        <div class="m-portlet m-portlet--head-solid-bg m-portlet--rounded" style="border-style: solid;">
            <div style="border-radius: 30px;">
                <br>
                <h4 style="text-align: center;">Equipo</h4>
                <h4 style="text-align: center;" class="name_text">({{@$mvp_team}})</h4>
                <br>
                 <h3 style="text-align: center;" id="vol_ac_act">{{@$mvp_team_per}} %</h3>
                <br>
            </div>
        </div>
    </div>
    <div class="col-md-2">
        <div class="m-portlet m-portlet--head-solid-bg m-portlet--rounded" style="border-style: solid;">
            <div style="border-radius: 30px;">
                <br>
                <h4 style="text-align: center;">Rival</h4>
                <h4 style="text-align: center;" class="name_text">({{@$mvp_rival}})</h4>
                <br>
                 <h3 style="text-align: center;" id="vol_ac_ant">{{@$rival_per}}%</h3>
                <br>
            </div>
        </div>
    </div>
    <div class="col-md-2">
        <div class="m-portlet m-portlet--head-solid-bg m-portlet--rounded" style="border-style: solid;">
            <div style="border-radius: 30px;">
                <br>
                <h4 style="text-align: center;">Equipo Rival</h4>
                <h4 style="text-align: center;" class="name_text">({{@$rival_team}})</h4>
                <br>
                 <h3 style="text-align: center;" id="vol_ac_variacion">{{@$rival_team_per}}%</h3>
                <br>
            </div>
        </div>
    </div>
        </div>
        <div class="row">
        	<div class="col-md-12">
            <table class="table table-striped- table-bordered table-hover table-checkable datatables_p">
                <thead>
                    <tr>
                        <th>Player</th>
                        <th>Games</th>
                        <th>Failed</th>
                        <th>Oport.</th>
                        <th> Op %</th>
                        <th>5.5%</th>
                        <th>4.5%</th>
                        <th>3.5%</th>
                        <th>2.5%</th>
                        <th>1.5%</th>
                        <th>0.5%</th>
                        <th>team</th>
                        <th>Matches</th>
                        <th>Success</th>
                        <th>3.5</th>
                        <th>2.5</th>
                        <th>1.5</th>
                        <th>0.5</th>
                        <th>GF</th>
                        <th>GA</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    @if(!empty($agrup))
                    @php $keys = 0;$fail= 0; @endphp
                        @foreach($agrup as $key => $bet)
                        @if($bet['partidos_jugados'] > 1)
                            <tr >
                                <td>{{ @$players_array[$bet['jugador']] }}</td>
                                <td>{{ $bet['partidos_jugados'] }}</td>
                                @php
                                    $por = round($bet['aciertos']*100/$bet['partidos_jugados']);
                                    $por_35 = round($bet['3_5']*100/$bet['partidos_jugados']);
                                    $por_15 = round($bet['1_5']*100/$bet['partidos_jugados']);
                                    $por_05 = round($bet['0_5']*100/$bet['partidos_jugados']);
                                    $por_45 = round($bet['4_5']*100/$bet['partidos_jugados']);
                                    $por_55 = round($bet['5_5']*100/$bet['partidos_jugados']);
                                    $por_65 = round($bet['6_5']*100/$bet['partidos_jugados']);
                                    $keys++;
                                    $fail = $bet['partidos_jugados'] - $bet['0_5'];
                                    $opo = $fail+($bet['0_5']-$bet['1_5']);
                                    $opo_por = $opo > 0 ? round(($opo-$fail) * 100 / $opo) : "-" ;
                                @endphp
                                <td>{{ $fail }}</td>
                                <td>{{ $opo }}</td>
                                <td>{{ $opo_por }}</td>
                                <td>{{round($por_55)}}</td>
                                <td>{{round($por_45)}}</td>
                                <td>{{round($por_35)}}</td>
                                <td>{{round($por)}}</td>
                                <td>{{round($por_15)}}</td>
                                <td>{{round($por_05)}}</td>
                                <td>
                                    <select class="form-control required teams" name="region_id">
                                        <option value="">Seleccione Equipo</option>
                                        @foreach($agrupTeam[$key] as $r => $v)
                                            @php
                                                $por_35 = round($v['3_5']*100/$v['partidos_jugados']);
                                                $por = $v['aciertos']*100/$v['partidos_jugados'];
                                                $por_15 = round($v['1_5']*100/$v['partidos_jugados']);
                                                $por_05 = round($v['0_5']*100/$v['partidos_jugados']);
                                            @endphp
                                            <option value="{{$r}}" attr-data="{{$bet['jugador']}},{{$v['partidos_jugados']}},{{$v['aciertos']}},{{round($por)}},{{$v['ga']}},{{$v['gc']}},{{$por_35}},{{$por_15}},{{$por_05}}">{{$v['team']}} ({{round($por)}}%)</option>
                                        @endforeach
                                    </select>
                                </td>
                                <td><label id="matches-{{$bet['jugador']}}"></label></td>
                                <td><label id="wins-{{$bet['jugador']}}"></label></td>
                                <td><label id="por-{{$bet['jugador']}}"></label></td>
                                <td><label id="por_3-{{$bet['jugador']}}"></label></td>
                                <td><label id="por_1-{{$bet['jugador']}}"></label></td>
                                <td><label id="por_0-{{$bet['jugador']}}"></label></td>
                                <td><label id="ga-{{$bet['jugador']}}"></label></td>
                                <td><label id="gc-{{$bet['jugador']}}"></label></td>
                                <td><input type="checkbox" class="compare" name="compare" id="compare_{{$keys}}" attr-player="{{$bet['jugador']}}" onclick="registrarCheck('{{$keys}}')"></td>
                            </tr>
                        @endif
                        @endforeach
                    @endif
                </tbody>
            </table> 
        </div>
	    <div class="col-md-12">
            <table class="table table-striped- table-bordered table-hover table-checkable datatables_p">
                <thead>
                    <tr>
                        <th>Player</th>
                        <th>Enemigo</th>
                        <th>Partidos</th>
                        <th>Failed</th>
                        <th>Opo</th>
                        <th>Oport. %</th>
                        <th>2.5(%)</th>
                        <th>3.5(%)</th>
                        <th>1.5(%)</th>
                        <th>0.5(%)</th>
                        <th>4.5(%)</th>
                        <th>5.5(%)</th>
                        <th>6.5(%)</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    @if(!empty($agrupEne))
                        @foreach($agrupEne as $ene)
	                        @foreach($ene as $bet2ene)
                                
	                        	<tr >
	                                <td>{{ @$players_array[$bet2ene['jugador']] }}</td>
	                                <td>{{ @$players_array[$bet2ene['enemigo']] }}</td>
	                                <td>{{ $bet2ene['partidos_jugados'] }}</td>
	                                @php

                                        $por = 0;
                                        $por_35 = 0;
                                        $por_15 = 0;
                                        $por_05 = 0;
                                        $por_45 = 0;
                                        $por_55 = 0;
                                        $por_65 = 0;
                                        $fail_ene = 0;


                                        if($bet2ene['partidos_jugados'] > 0){
                                            $por = @$bet2ene['aciertos']*100/@$bet2ene['partidos_jugados'];
                                            $por_35 = round($bet2ene['3_5']*100/$bet2ene['partidos_jugados']);
                                            $por_15 = round($bet2ene['1_5']*100/$bet2ene['partidos_jugados']);
                                            $por_05 = round($bet2ene['0_5']*100/$bet2ene['partidos_jugados']);
                                            $por_45 = round($bet2ene['4_5']*100/$bet2ene['partidos_jugados']);
                                            $por_55 = round($bet2ene['5_5']*100/$bet2ene['partidos_jugados']);
                                            $por_65 = round($bet2ene['6_5']*100/$bet2ene['partidos_jugados']);
                                            $fail_ene = $bet2ene['partidos_jugados'] - $bet2ene['0_5'];
                                            $opo_ene = $fail+($bet2ene['0_5']-$bet2ene['1_5']);
                                            $opo_por_ene = $opo_ene > 0 ? round(($opo_ene-$fail_ene) * 100 / $opo_ene) : "-" ;
                                        }
	                                @endphp
                                    <td>{{ $fail }}</td>
                                    <td>{{ $opo_ene }}</td>
                                    <td>{{ $opo_por_ene }}</td>
                                    <td>{{round($por)}} ({{@$bet2ene['aciertos']}})</td>
                                    <td>{{round($por_35)}} </td>
                                    <td>{{round($por_15)}} </td>
                                    <td>{{round($por_05)}} </td>
                                    <td>{{round($por_45)}} </td>
                                    <td>{{round($por_55)}} </td>
	                                <td>{{round($por_65)}} </td>
                                    <td><button type="button" id="" style="margin-top: 15px" class="btn btn-outline-warning compare_players" attr-player1="{{$bet2ene['jugador']}}" attr-player2="{{$bet2ene['enemigo']}}">Comparar</button></td>
	                            </tr>
	                        @endforeach
                            
                        @endforeach
                    @endif
                </tbody>
            </table> 
        </div>
        </div>
                <div class="col-md-12">
           <table class="table table-striped- table-bordered table-hover table-checkable datatables_p">
                <thead>
                    <tr>
                        <th>Player 1</th>
                        <th>Player 2</th>
                        <th>Team 1</th>
                        <th>Team 2</th>
                        <th>Fecha</th>
                        <th>Hora</th>
                        <th>RES </th>
                        <th>FT </th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    @php
                        $success = "#3a811d57";
                        $false = "#ff00002b";
                    @endphp
                    @if(!empty($bets))
                        @foreach($bets as $bet)
                            @php
                                $count_ft  = (int)$bet->finals1+(int)$bet->finals2;
                                $status = (float)$count_ft > 0? $success : $false ;
                                $status_text = (float)$count_ft > 0? "ok" : "fail" ;

                            @endphp
                            <tr style="background-color: {{$status}}">
                                <td>{{ $players_array[$bet->player1] }}</td>
                                <td>{{ $players_array[$bet->player2] }}</td>
                                <td>{{ $bet->team1 }}</td>
                                <td>{{ $bet->team2 }}</td>
                                <td>{{ $bet->fecha }}</td>
                                <td>{{ $bet->hora }}</td>
                                <td>{{ (int)$bet->finals1."-".(int)$bet->finals2 }}</td>
                                <td>{{ $count_ft }}</td>
                                <td>
                                    {{$status_text}}
                                </td>
                            </tr>
                        @endforeach
                    @endif
                </tbody>
            </table>
        </div>
        
    </div>
</div>
<script>

    array_find = [];

    registrarCheck = function(index){
        var item = {};  
        player = $('#compare_'+index).attr('attr-player')
        
        for (var i = 0; i < array_find.length; i++) {
            if ( (array_find[i] == player)) {
                array_find.splice(i, 1);
            };
        };

        if ($('#compare_'+index).is(':checked')) {
            array_find.push(player);
        }
    }


    $(document).ready(function() {
        $(".table").DataTable()

        $(".select2").select2();    

        $('input[name="daterange"]').daterangepicker({
             "startDate": "01/01/2024",
            ranges: {
                'Hoy': [moment(), moment()],
                'Ayer': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                'Últimos 3 días': [moment().subtract(3, 'days'), moment()],
                'Últimos 7 días': [moment().subtract(6, 'days'), moment()],
                'Últimos 30 días': [moment().subtract(29, 'days'), moment()],
                'Este Mes': [moment().startOf('month'), moment().endOf('month')],
                'Ultimo Mes': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
            },
            "alwaysShowCalendars": true
        }, function(start, end, label) {
          console.log('New date range selected: ' + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD') + ' (predefined range: ' + label + ')');
        });

        $(".teams").change(function(){
            selected = $(this).find("option:selected");
            teams_player = selected.attr("attr-data")
            teams_player_data = teams_player.split(",");
            elementoID = teams_player_data[0];
            elementoID = elementoID.replace(/\(/g, '\\(').replace(/\)/g, '\\)');
            $("#matches-"+elementoID).text(teams_player_data[1])
            $("#wins-"+elementoID).text(teams_player_data[2])
            $("#por-"+elementoID).text(teams_player_data[3])
            $("#ga-"+elementoID).text(teams_player_data[4])
            $("#gc-"+elementoID).text(teams_player_data[5])
            $("#por_3-"+elementoID).text(teams_player_data[6])
            $("#por_1-"+elementoID).text(teams_player_data[7])
            $("#por_0-"+elementoID).text(teams_player_data[8])
        })

        $("#load_players").click(function(){
            texto = $("#import_players_actual").val()
            const regex = /\((.*?)\)/g;
            let match;
            const nombresSet = new Set(); // Usamos un Set para evitar duplicados

            // Buscar todos los nombres entre paréntesis y almacenarlos en un Set
            while ((match = regex.exec(texto)) !== null) {
                nombresSet.add(match[0]); // Agregar el match completo (incluyendo paréntesis) al Set
            }

            // Convertir nombres a mayúsculas y mantener paréntesis
            nombresMayusculas = Array.from(nombresSet).map(nombre => {
                return nombre.toUpperCase();
            });

            // Imprimir los nombres en mayúsculas manteniendo paréntesis
            nombresMayusculas.forEach(nombre => {
                console.log(nombre)
            });

            //$("#players").val(nombresMayusculas).trigger('change');
            $("#players option").each(function() {
    // Comprueba si el texto de la opción está incluido en los nombres en mayúsculas
    if (nombresMayusculas.includes($(this).text().toUpperCase())) {
        // Marca la opción como seleccionada
        $(this).prop('selected', true);
    } else {
        // Desmarca la opción si no coincide
        $(this).prop('selected', false);
    }
});

// Dispara el evento de cambio
$("#players").trigger('change');
        })

        // Función para convertir un objeto en una cadena de consulta
        function objetoACadena(objeto) {
          var partes = [];
          for (var clave in objeto) {
            if (objeto.hasOwnProperty(clave)) {
              var valor = encodeURIComponent(objeto[clave]); // Codificar el valor
              partes.push(clave+';' + valor);
            }
          }
          return partes.join('&');
        }

        // Función para generar la cadena de consulta a partir del array de objetos
        function generarQueryStringDesdeArray(arr) {
        partes = arr.map(objetoACadena);
          return partes.join('&');
        }

        $(".compare_players").click(function(){

            p1 = $(this).attr('attr-player1')
            p2 = $(this).attr('attr-player2')

            var urlBase = '/bets_compare';
            urlCompleta = urlBase + '?player1=' + p1+ "&" + "player2="+ p2;
            window.open(urlCompleta, '_blank');
            array_find = []
        })

    })
</script>
@endsection
